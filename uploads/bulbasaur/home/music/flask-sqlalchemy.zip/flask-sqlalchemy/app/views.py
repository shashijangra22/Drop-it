from flask import render_template
from sqlalchemy import and_
from flask import url_for, redirect, request, make_response,flash
# Importing Session Object to use Sessions
from flask import session
from app.models import Post, User
from app import app, db



@app.route('/')
@app.route('/index')
def index():
	user = {'nickname': 'Mitesh'}
	posts = [
		{
			'author': {'nickname': 'Mitesh'},
			'body': 'Beautiful Day in Hyderabad!'
		},
		{
			'author': {'nickname': 'Mitesh'},
			'body': 'Andhadhun Movie was so cool.'
		}
	]
	return render_template('index.html',title='Home',user=user,posts=posts)

@app.route('/about')
def about():
	return render_template('about.html')


@app.route('/register')
def register():
	return render_template('register.html')

@app.route('/registerNext', methods = ['GET','POST'])
def registerNext():
	user = User(username=request.form["userid"],  password=request.form['loginpassword'])
	db.session.add(user)
	db.session.commit()
	flash('Your account has been created! You are now able to log in', 'success')
	return "Register Successful for: %s" % user.username


@app.route('/login')
def login():
	return render_template('login.html')

@app.route('/loginNext',methods=['GET','POST'])
def loginNext():
	# To find out the method of request, use 'request.method'
	if request.method == "GET":
		print request.args
		userID = request.args.get("userid")
		password = request.args.get("loginpassword")
		# Can perform some password validation here
		return "Login Successful for: %s" % userID
	elif request.method == "POST":
		userID = request.form['userid']
		password = request.form['loginpassword']
		# Can perform some password validation here!
		user  = User.query.filter(and_(User.username == userID, User.password == password)).first()
		if user:
			flash('Login successful', 'success')
			return "Login Successful for: %s" % user.username
		return "Password Error"


@app.route('/setCookie',methods=['GET','POST'])
def setCookie():
	if request.method == "POST":
		userID = request.form['userid']
		# Create the Response Object
		resp = make_response(render_template('landing.html'))
		# Set the cookie value. Will use this name to refer to the cookies later
		resp.set_cookie('userID',userID)
		return resp

@app.route('/readCookie')
def readCookie():
	# Get all the cookies in request.cookies and then get the cookie named userID
	userID = request.cookies.get('userID')
	return '<h1>Hello '+ userID +' !!</h1>'

@app.route('/home')
def homePage():
	# Check if userID session exists!
	if 'userID' in session:
		return 'Logged in As: ' + session['userID'] + ' <br> Click <a href="/logout">here</a> to logout!'
	return "You are not logged in! <br>Click <a href = '/loginSession'></b>Here</b></a> to Login!"

@app.route('/loginSession',methods=['GET','POST'])
def loginSession():
	if request.method == "POST":
		# Create a session variable
		session['userID'] = request.form['userid']
		return redirect(url_for('homePage'))
	return '''
	<form action = "" method = "post">
      <p><input type = "text" name = "userid" /></p>
      <p><input type = "submit" value = "Login" /></p>
   </form>
	
   '''

@app.route('/logout')
def logout():
	# Remove the session variable if present
	session.pop('userID',None)
	return redirect(url_for('homePage'))

@app.errorhandler(404)
def http_404_handler(error):
	return render_template('error404.html')